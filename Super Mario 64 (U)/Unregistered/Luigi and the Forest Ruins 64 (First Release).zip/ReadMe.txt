--------ENGLISH--------
Luigi and the Forest Ruins
****made by TheGael95****

Thanks for downloading this mini hack of SM64 !
It has 46 Stars... sorry, Ruin Tresaures, and 6 main levels.
(No, there isn't any 100 coin star in this, only 50 !)

For playing this, do the normal setup for playing SM64 hacks.


I'm no longer affiliated with  "Super Mario",Super Mario 64, Luigi, Bowser or any
Mario-related characters. They are all trademarks of Nintendo.

Also, sorry for not doing a custom title screen and changing internal ROM name !

------FRANCAIS-----
Luigi et les Ruines des Bois
****fait par TheGael95****

Merci d'avoir t�l�charg� ce mini hack de SM64 !
Il y a 46 �toiles... pardon, tr�sors des ruines, et 6 niveaux principaux.
(Non, il n'y a pas d'�toile des 100 pi�ces dedans !)

Pour y jouer, faites les r�glages normaux pour jouer � un hack de SM64.

Je ne suis associ� ni � "Super Mario", Super Mario 64, Luigi, Bowser ou n'importe quel
personnage de Mario. Ils appartiennent tous � Nintendo.

Ah oui, d�sol� de ne pas avoir fait un �cran titre personnalis� et de ne pas avoir chang�
le nom interne de la ROM !

PS : Vraiment d�sol� pour vous les fran�ais... mais j'ai pas fait de version
fran�aise. J'avais vraiment la flemme de la faire, en sachant que j'ai d�
utiliser la version am�ricaine de Super Mario 64 pour faire �a. En attendant,
essayez de comprendre un minimum l'anglais ;)
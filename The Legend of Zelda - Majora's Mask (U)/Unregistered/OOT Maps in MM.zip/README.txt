[ENG] -Pass the door of Mayor Office to make it work (East Clock Town).
      -For Hyrule Field patch, go into Termina Field (seems to doesn't work on PJ64...)
      -PUT ONE PATCH AT THE TIME !

Thanks to fkualol for the Hyrule Field port.

[FRA] -Passez la porte du Maire pour vous y t�l�porter (Bourg-Clocher Est).
      -Pour le patch Hyrule Field (Plaine d'Hyrule), allez dans la Plaine de Termina (ne semble pas fonctionner pour la PJ64...)
      -NE METTEZ QU'UN PATCH A LA FOIS !

Merci � fkualol pour l'import de la Plaine d'Hyrule.
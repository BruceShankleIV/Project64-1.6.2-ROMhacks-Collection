Star Revenge 7 - Park of Time v1.1
    SM64 hack by BroDute

This hack has 120 new stars
and all levels are replaced.
Mostly easy difficulty, so you shoudn't
have problems for the most part.

Story:
Mario is still stuck in the near future
and tries to get back into his
own time and suddenly finds a park.

About the levels. Most of the levels are
based around levels of the other
Star Revenges, so if something seems
familiar, you maybe know why. The levels to
say are all new modeld, only course 12 is
based on an old level model.

Unlike normal sm64 you are a bit more
free to explore from the get go. You are
mostly blocked by star doors. The keys
and caps switches play another role.

Badges.
Like in Paper Mario you can find badges in this hack.
There are 5 ones which will be explained by the
first sign you will encounter ingame.
And just to say, you will lose your triple jump and
walljump untill you have the badges for them...
so deal with it!!!
(also these were codet by Kaze | Grafics by me)

For the demo players:
You should still be able to keep your collected stars, BUT there are some changes in course 1, 2 and 5
with the stars, some changed the numbers so that you maybe have to recollect one. So if you
don't want to deal with that, then just start a now file, the hack wasn't so hard in the first 5
levels so it shouldn't be a problem. Just don't forget that you don't have a walljump now.

Credits:
Read the first sign.

Btw Bowser isn't in this hack, specially Bowser fight
1 + 2, they are useles, they are better if they are replaced
with an other boss. Nobody wants to see Bowser 1+2!

Also there are some references to Twitch streamers or YouTuber in this hack, maybe you will seen them.
Anyways have fun �3�

-If you find any bugs tell me, so could fix them later (and no, I don't want to hear how you get stuck in trees)-
-When you maybe hear a okidoki while just starting in a level, that is normal, that comes from the badges, which
doesn't mean, that if you hear it in a level that there is automaticly one in this level-

                       - BroDute
            - Original Game by Nintendo














































































































































































































Watch for the red coin counter of star display in one level






























































































































































Star Revenge 6.25
    Luigi's Adventure DX 
                                 v1.1
----------------------------------------------------
This SM64 hack is a remake of Star Revenge 6 LA.
There are 216 stars to collect in mostly easy to normal levels.
Every star has a name, even in side levels (but not the overworld), and the names can be viewed via the pause screen in each level.
The overworld has a StarDisplay-like feature as the pause screen.
10 of the main courses are reimagined, 2 edited and the rest is all new levels.
The hack has also a custom boss fight.
There are multiple endings in this hack. Getting to one will give you a password which allows you to view concept/sketches of the levels of this hack. (The last one contains stuff from other hacks)
----------------------------------------------------
The .dll file? It's an audio plugin for emulators that will prevent some music cracking in 2 songs.
----------------------------------------------------
Credits:

Original game: Nintendo
Level models: BroDute
Textures: BroDute, SMW Central
HUD Textures: BroDute

Music: Watch the music folder (contains spoilers)
Special thanks to Retro Reviver for making a ton of songs from requests

Luigi Voice Clips: UsernamesAreSpiders

Codes:
original MOP objects: Kaze | MOP improvments: Aglab2
Yellow switch: Scuttlebug_Raiser
Cap Timer: ToasterKetchup
Normal Timer position: Blakeoramo
HUD Rearangement (Tool): PilzInsel64
ALL OTHER CODES: Aglab2

Text correction: Mushie64

Beta Testers: LinCrash, Aglab2, TheRidiculousR, Mushie64
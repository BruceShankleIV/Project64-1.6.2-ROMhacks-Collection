Star Revenge 7.5 - Kedowser's Return v1.1
    SM64 hack by BroDute

This hack has 130 new stars
and all levels are changed versions of the ones from SR7.
It is harder compared to SR7.

You will need the password of SR7 (which you
can find at the top of Castle Wakati Tower) to beat this hack.

Story:
After falling in the trap of Timerock to get him so much star power
to bring back Kedowser, Mario has now to collect 130 new stars to
face off the Timerock and co. to finally get back to his own time era.
Yet Kedowser did his part and took over many places already and changed them.

Levels:
Most of the levels are still the same, but they all have some changes in them
which make them very different from SR7. Next to the old levels there are also
some compleatly new ones, but most of them are of the first kind.
Also the stars are just like SR6.5 hidden like SMG2 green stars and the
star title is not much help.

Badges:
The same badges as SR7 had, but just in different locations now.


Credits:
Read the first sign.



-If you find any bugs tell me, so could fix them later (and no, I don't want to hear how you get stuck in trees or the game crashes, that is stuff you have to deal with)-
-When you maybe hear a okidoki while just starting in a level, that is normal, that comes from the badges, which
doesn't mean, that if you hear it in a level that there is automaticly one in this level-

                       - BroDute
            - Original Game by Nintendo
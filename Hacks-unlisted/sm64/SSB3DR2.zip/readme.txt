--------Super Smash Bros. 3D R2, by Skelux--------

The controls for SSB3D are the same as Super Smash Bros. 64, except all moves that require you to press DOWN are substituted for Z.
The same goes for moves involving the 'Jump' button - for example, you can press C-DOWN + B for the attack-jump move.
Since the entire analogue stick is used for movement, only C-DOWN is used for jumping now.
Some moves are not yet added and will be included in future revisions. For now, you can dodge by crouching.

To play online, you can use the emulator included. The most popular method is Kaillera:
First go into 'Options' then 'Settings' and set the ROM directory to where SSB3D is located.
Click 'File' and 'Stat Kaillera...', enter your name, then click 'Master Servers List'.
Join a server and right-click below the chat window to host a game your friends can join.
To set up the controls, go into 'Options' then 'Configure Controller Plugin...' and go to the 'Player 2' tab.

The second option is to use the AQZ plugin, which is much more stable and does not desync.
You can select AQZ from the input plugins menu, please search online for a detailed guide.

--------Credits--------

Hailbot: Model rips for SSBB stages, title screen logo, Metal Man stage model
PablosCorner: All music imports, excluding GC Peach's Castle
Quasmok: Hud graphics
Subdrag: N64 Sound Tool usage

--------FAQ--------

Q. Where can I find your other work?
A. https://www.youtube.com/user/Skelux/

Q. Is there somewhere I can support you projects?
A. https://www.patreon.com/skelux

Q. What alternative emulators would you recommend?
A. You could try Mupen64++ or an AQZ plugin, both of which will allow you to save your progress.

Q. I have another question, where can I ask it?
A. http://origami64.net/

--------Planned Features--------

*Character selection, many characters
*Finished base move sets (blocking, grabbing...)
*4-players
*CPU/AI players
*Story Mode, Smash the Target, etc
*Items
*N64 compatibility
*More announcer voices
*Various bug fixes and fine-tuned gameplay

--------Change Log--------

Revision 2:
*3 new stages, Metal Man, GC Peach's Castle, and N64 Battlefield
*Cooldown for fireball attack matches SSB64
*Players don't take damage if both are attacking upon collision
*Disabled ground-pound while hanging from ledge (SSB64 ledge recovery attacks will be added eventually)
*No bounce when landing from air kick, and action ends sooner

Revision 1:
*Initial release, contains all the core physics and such.
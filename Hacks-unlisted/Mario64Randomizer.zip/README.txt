SM64 Hack Randomizer allows to change Mario's Clothes, Warps, Objects, Music based on seed.

Changelog

Version 1.2.1:
Courses always object randomized, renames

Version 1.1.1:
Fixed Save Config not loading warps

Version 1.1:
General:
The program now allows to save / load generic config files for any romhack. A config file being a whitelist of warps / objects that are able to be randomized.

Warps / Courses:
The randomizer now gets the course names from the Rom File
Randomize Warps to Hubs are now an optional Checkbox
The Warp randomizer now has checks for Interior and Exterior Warps
The Course Names are now saved in the warp
Lots of new Logic Checks to prevent Crashes
Removeable Warps (by Address)

Objects:
New Options to remove Grounded / Warp Objects
List of Removed Objects (by Address)

Music:
Music Randomizer now chooses between Checked Courses. Small / Medium hacks will now only randomize music within available courses

const effectTitles = [
"debug",
"slowrotate",
"movebackwards",
"buttonswap",
"rupeechange",
"heattimer", //
"randombombtimer", //
"airstrike", //
"swapcbuttons", //
"changebbutton", //
"icefloor",
"sunssong",
"ignorewater",
"noztarget",
"snaptofloor",
"upsidedownscreen", //
"randomitem",
"icetrap",
"textbox",
"junkitem",
"randomplayersounds",
"allsfxisplayer",
"tuniccolor",
"musicswap", //
"disablesword",
"environment",
"useocarina",
"lowgravity",
"randomknockback",
"earthquake",
"limbspin", //
"isg",
"speedup",
"speeddown",
"giant",
"putaway",
"fastanims",
"slowanims",
"quicksand",
"puzzle",
"entrancerando", //
"signpost",
"weirdarrows",
"ambush",
"voidout",
"noautojump", //
"noclimbup",
"nocollectibles", //
"actorchase",
"electrocute",
"randomteleport",
"ohko",
"healthchange",
"magicchange",
"zerodmgweapons",
"swaphealandhurt", //
"takescreenshot",
"showscreenshot",
"badmusic",
"dive",
"timerup", //
"highping",
"songofstorms",
"climbeverything",
"starfox",
"navi", //
"butterfingers", // formerly deathmountainrocks
"incredibleknockback",
"likelike", // formerly babydodongo
"swordtrail",
"tpmagicarmor",
"antivirus",
"hoverboots",
"randomhealthup",
"randomhealthdown",
"endoftheworld",
"theworldissaved",
"fiercedeity",
"invincible",
"getlostitem",
"shorttermmemory",
];

const cachePath = "unset";
const gTwitchFlag = 0x806001A0;
const gEffectQueue = 0x806001A2;
const gNameBuffer = 0x806001A4;


function addEffect(effect) {
    console.log("add effect " + effectTitles[effect]);
    mem.u16[gEffectQueue] = effect;
    return;
}

function parseInput() {
    console.listen(function(input) {
        if (fs.exists(input + "\\Streamer.bot.exe")) { // is streamer bot folder
            console.log("found Streamer.bot!");
            if (!fs.exists(input + "\\ootChaosCache")) { // cache folder doesn't exist yet
                fs.mkdir(input + "\\ootChaosCache");
            }
            console.log("cache path set to: " + input + "\\ootChaosCache\\");
            cachePath = (input + "\\ootChaosCache\\");
        } else { // is not streamer bot folder
            console.log("couldn't find " + input + "\\Streamer.bot.exe");
        }
    });
    //console.log("path");
}

function main() {
    parseInput();

    if (!fs.exists(cachePath)) {
        mem.u8[gTwitchFlag] = 2;
        return;
    }

    var files = fs.readdir(cachePath);
    var index = 0;
    var effectIndex = 0;

    mem.u8[gTwitchFlag] = 1;

    if (mem.u16[gEffectQueue] != 0) {
        //console.log("queue is busy.");
    } else {
        for (effectIndex = 0; effectIndex < effectTitles.length; effectIndex++) {
            //console.log("check for: " + effectTitles[effectIndex]);
            for (index = 0; index < files.length; index++) {
                if (files[index].includes(effectTitles[effectIndex])) {
                    //var buffer = fs.readfile(files[index]);
                    //mem.setblock(gNameBuffer, buffer);
                    //console.log("found first instance of " + effectTitles[effectIndex] + " at " + (cachePath + files[index]));
                    addEffect(effectIndex);
                    fs.unlink(cachePath + files[index]);
                    break;
                }
            }
        }
    }
}

console.log("please enter streamer.bot installation folder path in the input box below.");
setInterval(main, 2);

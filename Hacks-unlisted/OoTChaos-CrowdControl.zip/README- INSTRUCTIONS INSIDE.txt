-- OoT Chaos Mod Crowd Control --

The mod has built in functionality for communicating between a Project64 Script and Streamer.bot.
It has been tested with Twitch, but Streamer.bot has compatibility for other platforms (YouTube) as well.

-- Introduction --

The following instructions will help you get started, however this is NOT a Streamer.bot tutorial.
Advanced usage of Streamer.bot (ex. donation events) will not be covered in these instructions.
Sample chat commands have been provided, more info will be provided in Step 4.

-- Instructions --

1. Install Compatible Project64 Version:

	You must use a version of Project64 with the new scripting API.

	(UPDATE 8/13/23) Here's a seemingly stable build: https://www.pj64-emu.com/file/project64-dev-4-0-0-5741-e60f7ec/

2. Configure Project64

	Open Project64, then under Options > Configuration > General Settings, uncheck "Hide advanced settings."
	Then under the newly visible "Advanced" submenu, check "Enable debugger."

	(UPDATE 8/13/23) If the file select screen crashes, check "Always use interpreter core" as well.

	Close the Options window, then go to Debugger > Scripts.
	Click the three dots button below the Scripts box to open the folder containing your Scripts.
	Paste the included file, "ootChaosPJ64Script.js", inside of this folder.

	We are now finished with Project64 for now. We'll open it again when we're ready to play the game.

3. Install Streamer.bot

	Streamer.bot is a program for communication between a streaming platform and additional programs.
	If you don't already use it, download it at: https://streamer.bot/

	Make note of the location that you install the program in, as you'll need it later to link the script.

4. Import Streamer.bot Actions

	In Streamer.bot, there is an "Import" button at the top of the screen. Click on it.
	In the new window, paste the contents of included file "ootChaosActions.txt" into the "Import Actions" box.
	It should now show you a list of chaos effects under the Actions tab.

	OPTIONAL:
	You can also choose to instead paste the contents of included file "ootChaosSampleCommands.txt" to
	import some basic chat commands for Twitch alongside the Actions. You have to set the Commands to
	"Enabled" before they'll work. Streamer.bot will tell you this with a pop-up window when you Import 
	them.

	When you're ready, press Import at the bottom right of the window.

5. Log in to Streamer.bot

	Log in under the Platforms subsection of Streamer.bot. More info can be found online.

6. Start OoT Chaos Mod in Project64

	Reopen Project64 and start the ROM you patched for OoT Chaos Mod. (Patch included separately.)
	Go to Debugger > Scripts and double click "ootChaosPJ64Script.js" under the Scripts box.
	It should turn green.

	The output box will ask you to enter the path you installed Streamer.bot in.
	In the wide black box at the bottom of the window, type in the full path to Streamer.bot's folder.
	Do NOT include a slash at the end of the path.

	(Example: C:/Program Files/Streamer.bot)
	(Bad Example: C:/Program Files/Streamer.bot/)

	The script will now look for Streamer.bot. If successful, it will say "found Streamer.bot!"
	It will then set a path for effect cache. This is automatic, you don't have to do anything.
	
7. Play the Game

	The script should now be linked to Steamer.bot! In-game if you hold D-Pad right, the top of the
	screen should now display "crowd control." If it instead says "script awaiting input..." that means
	you did not give the script the correct path to Streamer.bot.

	Actions in Streamer.bot have to be invoked with Events or Commands. You need to make these yourself,
	though I included some sample Commands for Twitch. (See Step 4.)

	For more info on this, please look up a Streamer.bot tutorial.

	Good luck!!
	- Aegiker

